# AI-fellowship-exam
Solution to the Exam 2