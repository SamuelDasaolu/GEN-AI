# Task 1
print("This is Task 1")
name = input("What is your Name? ")
age = input("What is your Age? ")
print(f"Welcome {name}, you are {age} years old")