# Task 5
print("This is Task 5")
market_name = input("Please input market name: ")
no_of_traders = int(input("Input number of traders: "))
daily_revenue = float(input("Input daily revenue in NGN: "))
result = f"Market Name: {market_name} \n Number of traders: {no_of_traders:,} \n Daily Revenue in Naira: {daily_revenue:,.2f} \n"
print(result)