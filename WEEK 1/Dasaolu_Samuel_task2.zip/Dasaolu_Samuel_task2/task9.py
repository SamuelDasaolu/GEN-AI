# Task 9
print("This is Task 9")
festival_name = input("Enter the name of the Nigerian festival: ")
location = input("Enter the location of the festival: ")
month = input("Enter the month the festival is held: ")
print(f"The \"{festival_name}\" festival is held in {location} in the month of {month}.")
