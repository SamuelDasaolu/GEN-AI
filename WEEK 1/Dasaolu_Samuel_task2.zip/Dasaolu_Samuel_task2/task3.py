# Task 3
print("This is Task 3")
name = input("What is your Name? ")
student_class = input("What class are you? ")
state_of_origin = input("What is your state of origin? ")
print(f"Student {name} is in {student_class} and is from {state_of_origin}")
