# Task 2
print("This is Task 2")
price_of_garri = float(input("Please input the price of garri in Naira: "))
print("Today, the price of garri is NGN", price_of_garri, "Kobo")
