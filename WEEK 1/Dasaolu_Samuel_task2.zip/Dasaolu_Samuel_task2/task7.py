# Task 7
print("This is Task 7")
age = int(input("Enter your age: "))
height = float(input("Enter your height in meters: "))
name = input("Enter your name: ")
print(f"My name is {name}, I am {age} years old, and my height is {height} meters.")
