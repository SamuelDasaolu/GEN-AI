# Task 4
print("This is Task 4")
dish = input("Pleas, name a nigerian dish: ")
dish_state = input("Please name the state it is popular in: ")
print(f"The popular dish is: {dish} and it is popular in \n \t {dish_state} State")
